$(document).ready(function() {
  $("div").click(function() {
	alert("Hello Friends!");
  });
});
