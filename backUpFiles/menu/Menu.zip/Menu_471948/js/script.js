$('ul li:nth-child(5)').click(function(){
	$('ul li:nth-child(5)').append('<ul class="child"><li>Ada</li><li>Saarland</li><li>Salzberg an der schonen Donau</li></ul>');
});
$('ul li:nth-child(7)').click(function(){
	$('ul li:nth-child(5)').append('<ul class="child"><li>Ada</li><li>Saarland</li><li>Salzberg an der schonen Donau</li></ul>');
});